RUN GRAPHICAL MODELER:
======================
Upon logon the graphical modeler part of SecuriTAS will launch 
immediately.If this is not the case, the Run_Graphical_Modeler_SecuriTAS.bat 
file on desktop as administrator for to launch Eclipse with the AccessControl 
demo project.

RUN ADAPTATION MANAGER:
=======================
To start the adaptation manager, you must right click and select 
run as administrator for the Run_Adaptation_Manager.bat file on desktop. This
is a slightly modified version of the installer that creates all the temporary
files for SecuriTAS adaptation manager to run. After a demo session it is 
recommended that you reboot the VM for another demo if needed, since SecuriTAS
does not do a clean up of the resources it initializes.

***Important***
If you manage to thrash the system, or the adaptation manager launch would not work
as expected, you can do a clean run again by running the Cleanup.bat file on desktop
as administrator. This should install a fresh copy of the tool and you can relaunch 
the adaptation manager by running the batch file as admin again after running the 
cleanup.
***Important***

Launching the batch file would require you to press your keyboard a few times to
progress through the launch process. The only time you have to give input is when
the process asks for the MySQL root passowrd. This password is paperino as printed
on the command prompt and is unfortunately hardcoded into SecuriTAS, hence must be
provided manually verbatim.

The last step of the launch process is starting jBoss server, which will take
about a minute. After jBoss has started, launch process will notify you, and then
press a key to launch the adaptation manager in the default browser. That's it!

Play around SecuriTAS, watch the video if you don't like reading READMEs.


On behalf of Team Carteret,
Shaown S.
(ssarker@ncsu.edu)

***Disclaimer***
The sole reason this tool is presented in a windows VM is that the authors of the
tool prepared the binary of the tool and tested it in a 32-bit windows system. Check
the official installation guide for that. The tool requires running a few very Windows
specific command and assumes a directory called C:\Runner\DACFile. I personally tried
the tool to run on OS X but was not successful.
***Disclaimer***
