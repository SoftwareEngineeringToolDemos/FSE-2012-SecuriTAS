-- MySQL dump 10.13  Distrib 5.1.61, for Win32 (ia32)
--
-- Host: localhost    Database: lessons
-- ------------------------------------------------------
-- Server version	5.1.61-community

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

DROP DATABASE IF EXISTS lessons;
CREATE DATABASE lessons;
USE lessons;

--
-- Table structure for table `asset`
--

DROP TABLE IF EXISTS `asset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asset` (
  `name` varchar(255) NOT NULL,
  `byteCode` tinyblob,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asset`
--

LOCK TABLES `asset` WRITE;
/*!40000 ALTER TABLE `asset` DISABLE KEYS */;
INSERT INTO `asset` VALUES ('Computer','\0\0\0\0\0\0\0\0\0\0\0\0');
/*!40000 ALTER TABLE `asset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authenticationsystem`
--

DROP TABLE IF EXISTS `authenticationsystem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authenticationsystem` (
  `id` int(11) NOT NULL,
  `fingerprint` bit(1) DEFAULT NULL,
  `nfc` bit(1) DEFAULT NULL,
  `password` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authenticationsystem`
--

LOCK TABLES `authenticationsystem` WRITE;
/*!40000 ALTER TABLE `authenticationsystem` DISABLE KEYS */;
/*!40000 ALTER TABLE `authenticationsystem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logrecord`
--

DROP TABLE IF EXISTS `logrecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logrecord` (
  `time` datetime NOT NULL,
  `cardKeyNumber` tinyblob,
  `UserName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logrecord`
--

LOCK TABLES `logrecord` WRITE;
/*!40000 ALTER TABLE `logrecord` DISABLE KEYS */;
INSERT INTO `logrecord` VALUES ('2012-05-19 15:42:55','\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',NULL),('2012-05-19 15:43:14','\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',NULL),('2012-05-19 15:48:33','\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',NULL),('2012-05-19 15:48:42','\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',NULL),('2012-05-19 15:55:07','\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',NULL),('2012-05-19 15:55:14','\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',NULL),('2012-05-19 15:55:21','\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',NULL),('2012-05-19 16:34:46',NULL,'Liliana.Pasquale'),('2012-05-19 16:34:53',NULL,'Bashar.Nuseibeh'),('2012-05-19 16:35:00',NULL,'Luca.Cavallaro'),('2012-05-19 18:23:04',NULL,'Liliana.Pasquale'),('2012-05-19 18:23:12',NULL,'Claudio.Menghi'),('2012-05-19 18:25:54',NULL,'Luca.Cavallaro'),('2012-05-19 18:26:00',NULL,'Claudio.Menghi'),('2012-05-19 18:40:03',NULL,'Claudio.Menghi'),('2012-05-19 18:40:08',NULL,'Claudio.Menghi'),('2012-05-19 18:45:58',NULL,'Claudio.Menghi'),('2012-05-19 18:46:04',NULL,'Bashar.Nuseibeh'),('2012-05-19 18:46:12',NULL,'Luca.Cavallaro'),('2012-05-20 14:25:52',NULL,'Bashar.Nuseibeh'),('2012-05-20 14:25:59',NULL,'Claudio.Menghi'),('2012-05-20 14:33:53',NULL,'Claudio.Menghi'),('2012-05-20 14:46:23',NULL,'Claudio.Menghi'),('2012-05-20 14:51:31',NULL,'Claudio.Menghi'),('2012-05-20 14:57:36',NULL,'Claudio.Menghi'),('2012-05-20 15:26:26',NULL,'Claudio.Menghi'),('2012-05-20 15:30:02',NULL,'Claudio.Menghi'),('2012-05-20 15:44:48',NULL,'Claudio.Menghi'),('2012-05-21 11:18:06',NULL,'Claudio.Menghi'),('2012-05-21 11:18:16',NULL,'Claudio.Menghi'),('2012-05-21 11:18:37',NULL,'Bashar.Nuseibeh'),('2012-05-22 01:34:48',NULL,'Bashar.Nuseibeh'),('2012-05-22 01:35:06',NULL,'Luca.Cavallaro'),('2012-05-22 01:41:58',NULL,'Bashar.Nuseibeh'),('2012-05-22 01:46:23',NULL,'Bashar.Nuseibeh'),('2012-05-22 01:53:16',NULL,'Bashar.Nuseibeh'),('2012-05-22 02:11:21',NULL,'Bashar.Nuseibeh'),('2012-05-22 02:29:36',NULL,'Bashar.Nuseibeh'),('2012-05-22 02:34:54',NULL,'Bashar.Nuseibeh'),('2012-05-22 04:46:06',NULL,'Bashar.Nuseibeh'),('2012-05-22 04:46:19',NULL,'Liliana.Pasquale'),('2012-05-22 04:46:48',NULL,'Bashar.Nuseibeh'),('2012-05-22 04:47:37',NULL,'Bashar.Nuseibeh'),('2012-05-22 04:47:51',NULL,'Liliana.Pasquale'),('2012-05-22 04:48:08',NULL,'Claudio.Menghi'),('2012-05-22 04:48:17',NULL,'Luca.Cavallaro'),('2012-05-22 05:30:01',NULL,'Claudio.Menghi'),('2012-05-22 05:30:11',NULL,'Luca.Cavallaro'),('2012-05-22 05:30:20',NULL,'Liliana.Pasquale'),('2012-05-22 05:30:30',NULL,'Bashar.Nuseibeh'),('2012-05-22 12:15:42',NULL,'Luca.Cavallaro'),('2012-05-22 12:15:53',NULL,'Claudio.Menghi'),('2012-05-22 12:16:00',NULL,'Liliana.Pasquale'),('2012-05-22 12:16:07',NULL,'Bashar.Nuseibeh'),('2012-05-22 12:44:04',NULL,'Liliana.Pasquale'),('2012-05-22 12:44:19',NULL,'Claudio.Menghi'),('2012-05-22 12:44:30',NULL,'Bashar.Nuseibeh'),('2012-05-22 12:44:57',NULL,'Liliana.Pasquale'),('2012-05-22 12:46:09',NULL,'Claudio.Menghi'),('2012-05-22 12:46:25',NULL,'Liliana.Pasquale'),('2012-05-22 12:46:32',NULL,'Bashar.Nuseibeh'),('2012-05-26 12:39:51',NULL,'Luca.Cavallaro'),('2012-05-26 12:44:52',NULL,'Luca.Cavallaro'),('2012-05-26 12:47:26',NULL,'Luca.Cavallaro'),('2012-05-26 12:47:39',NULL,'Bashar.Nuseibeh'),('2012-05-26 12:47:46',NULL,'Bashar.Nuseibeh'),('2012-05-26 12:47:55',NULL,'Liliana.Pasquale'),('2012-05-26 12:50:58',NULL,'Claudio.Menghi'),('2012-05-26 12:51:07',NULL,'Liliana.Pasquale'),('2012-05-26 12:51:14',NULL,'Bashar.Nuseibeh'),('2012-05-26 12:56:47',NULL,'Claudio.Menghi'),('2012-05-26 12:56:59',NULL,'Luca.Cavallaro'),('2012-05-26 12:57:07',NULL,'Liliana.Pasquale'),('2012-05-26 12:57:13',NULL,'Bashar.Nuseibeh'),('2012-05-26 13:04:57',NULL,'Luca.Cavallaro'),('2012-05-26 13:05:08',NULL,'Liliana.Pasquale'),('2012-05-26 13:05:14',NULL,'Bashar.Nuseibeh'),('2012-05-26 13:05:23',NULL,'Claudio.Menghi'),('2012-05-26 13:05:28',NULL,'Bashar.Nuseibeh'),('2012-05-26 13:05:59',NULL,'Bashar.Nuseibeh'),('2012-05-26 13:06:11',NULL,'Bashar.Nuseibeh'),('2012-05-26 13:39:07',NULL,'Liliana.Pasquale'),('2012-05-26 13:39:17',NULL,'Luca.Cavallaro'),('2012-05-26 13:39:23',NULL,'Claudio.Menghi'),('2012-05-26 13:39:28',NULL,'Bashar.Nuseibeh'),('2012-05-26 13:39:39',NULL,'Bashar.Nuseibeh'),('2012-05-26 13:41:01',NULL,'Bashar.Nuseibeh'),('2012-05-27 18:19:17',NULL,'Bashar.Nuseibeh'),('2012-05-27 18:21:40',NULL,'Liliana.Pasquale'),('2012-05-27 18:22:08',NULL,'Claudio.Menghi'),('2012-05-27 18:22:24',NULL,'Luca.Cavallaro'),('2012-05-27 18:28:09',NULL,'Claudio.Menghi'),('2012-05-27 18:28:18',NULL,'Liliana.Pasquale'),('2012-05-27 18:28:24',NULL,'Liliana.Pasquale'),('2012-05-27 18:28:40',NULL,'Liliana.Pasquale'),('2012-05-27 19:30:55',NULL,'Claudio.Menghi'),('2012-05-27 19:31:01',NULL,'Liliana.Pasquale'),('2012-05-27 19:31:10',NULL,'Bashar.Nuseibeh'),('2012-05-27 19:31:25',NULL,'Liliana.Pasquale'),('2012-05-27 22:47:35',NULL,'Liliana.Pasquale'),('2012-05-27 22:47:48',NULL,'Claudio.Menghi'),('2012-05-27 22:59:17',NULL,'Claudio.Menghi'),('2012-05-27 23:05:53',NULL,'Claudio.Menghi'),('2012-05-27 23:06:06',NULL,'Luca.Cavallaro'),('2012-05-27 23:13:03',NULL,'Claudio.Menghi'),('2012-05-27 23:13:14',NULL,'Claudio.Menghi'),('2012-05-27 23:16:48',NULL,'Claudio.Menghi'),('2012-05-27 23:17:00',NULL,'Luca.Cavallaro'),('2012-05-27 23:17:07',NULL,'Liliana.Pasquale'),('2012-05-27 23:18:09',NULL,'Claudio.Menghi'),('2012-05-27 23:18:17',NULL,'Liliana.Pasquale'),('2012-05-27 23:18:39',NULL,'Bashar.Nuseibeh'),('2012-05-27 23:19:18',NULL,'Claudio.Menghi'),('2012-05-27 23:19:38',NULL,'Luca.Cavallaro'),('2012-05-27 23:19:50',NULL,'Liliana.Pasquale'),('2012-05-27 23:20:45',NULL,'Claudio.Menghi'),('2012-05-28 13:42:15',NULL,'Claudio.Menghi'),('2012-05-28 13:42:18',NULL,'Claudio.Menghi'),('2012-05-28 13:42:26',NULL,'Liliana.Pasquale'),('2012-05-28 13:58:50',NULL,'Liliana.Pasquale'),('2012-05-28 13:58:56',NULL,'Claudio.Menghi'),('2012-05-28 13:59:35',NULL,'Liliana.Pasquale'),('2012-05-28 14:06:21',NULL,'Bashar.Nuseibeh'),('2012-05-28 14:07:30',NULL,'Liliana.Pasquale'),('2012-05-28 14:07:37',NULL,'Claudio.Menghi'),('2012-05-30 21:22:21',NULL,'Luca.Cavallaro'),('2012-05-31 10:00:41',NULL,'Luca.Cavallaro'),('2012-05-31 10:01:10',NULL,'Liliana.Pasquale'),('2012-05-31 10:01:34',NULL,'Claudio.Menghi'),('2012-05-31 10:01:36',NULL,'Claudio.Menghi'),('2012-05-31 10:01:57',NULL,'Bashar.Nuseibeh'),('2012-05-31 10:03:45',NULL,'Luca.Cavallaro'),('2012-05-31 10:03:51',NULL,'Claudio.Menghi'),('2012-05-31 10:03:57',NULL,'Liliana.Pasquale'),('2012-05-31 10:04:22',NULL,'Luca.Cavallaro'),('2012-05-31 10:04:32',NULL,'Liliana.Pasquale'),('2012-05-31 10:04:41',NULL,'Claudio.Menghi'),('2012-05-31 10:04:51',NULL,'Bashar.Nuseibeh'),('2012-05-31 10:05:03',NULL,'Claudio.Menghi'),('2012-05-31 10:05:10',NULL,'Liliana.Pasquale'),('2012-05-31 10:44:29',NULL,'Liliana.Pasquale'),('2012-05-31 10:44:34',NULL,'Claudio.Menghi'),('2012-05-31 10:45:03',NULL,'Liliana.Pasquale'),('2012-05-31 10:45:54',NULL,'Bashar.Nuseibeh'),('2012-05-31 10:46:17',NULL,'Liliana.Pasquale'),('2012-05-31 10:46:25',NULL,'Claudio.Menghi'),('2012-05-31 11:36:42',NULL,'Luca.Cavallaro'),('2012-05-31 11:37:01',NULL,'Liliana.Pasquale'),('2012-05-31 11:37:06',NULL,'Luca.Cavallaro'),('2012-05-31 11:37:12',NULL,'Bashar.Nuseibeh'),('2012-05-31 11:37:21',NULL,'Claudio.Menghi'),('2012-05-31 13:19:45',NULL,'Bashar.Nuseibeh'),('2012-05-31 13:19:57',NULL,'Bashar.Nuseibeh'),('2012-05-31 13:20:25',NULL,'Bashar.Nuseibeh'),('2012-05-31 13:20:57',NULL,'Bashar.Nuseibeh'),('2012-05-31 13:21:11',NULL,'Bashar.Nuseibeh'),('2012-05-31 14:42:58',NULL,'Liliana.Pasquale'),('2012-05-31 14:52:48',NULL,'Liliana.Pasquale'),('2012-05-31 14:52:49',NULL,'Liliana.Pasquale'),('2012-05-31 14:53:09',NULL,'Liliana.Pasquale'),('2012-05-31 15:25:42',NULL,'Luca.Cavallaro'),('2012-05-31 16:16:08',NULL,'Liliana.Pasquale'),('2012-05-31 16:16:15',NULL,'Claudio.Menghi'),('2012-05-31 16:17:04',NULL,'Liliana.Pasquale'),('2012-05-31 16:17:39',NULL,'Bashar.Nuseibeh'),('2012-05-31 16:18:12',NULL,'Liliana.Pasquale');
/*!40000 ALTER TABLE `logrecord` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `role` varchar(255) NOT NULL,
  `access` bit(1) DEFAULT NULL,
  PRIMARY KEY (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES ('PostDoc',''),('Professor',''),('Student','');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userdata`
--

DROP TABLE IF EXISTS `userdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userdata` (
  `username` varchar(255) NOT NULL,
  `cardKey` tinyblob,
  `email` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `surname` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`username`),
  KEY `FKF01672151609DD65` (`role`),
  CONSTRAINT `FKF01672151609DD65` FOREIGN KEY (`role`) REFERENCES `role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userdata`
--

LOCK TABLES `userdata` WRITE;
/*!40000 ALTER TABLE `userdata` DISABLE KEYS */;
INSERT INTO `userdata` VALUES ('Bashar.Nuseibeh','\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',NULL,'Bashar','Passoword','Nuseibeh','Professor'),('Claudio.Menghi','\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',NULL,'Claudio','Passoword','Menghi','Student'),('Liliana.Pasquale','\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',NULL,'Liliana','Passoword','Pasquale','PostDoc'),('Luca.Cavallaro','\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',NULL,'Luca','Passoword','Cavallaro','PostDoc');
/*!40000 ALTER TABLE `userdata` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-06-21 22:58:17
